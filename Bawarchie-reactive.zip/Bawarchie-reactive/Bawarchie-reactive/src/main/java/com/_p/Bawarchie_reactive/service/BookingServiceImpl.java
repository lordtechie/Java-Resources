package com._p.Bawarchie_reactive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com._p.Bawarchie_reactive.entity.Booking;
import com._p.Bawarchie_reactive.repository.BookingRepository;

import reactor.core.publisher.Mono;


@Service
public class BookingServiceImpl implements BookingService{
	
	@Autowired
	private BookingRepository bookingRepository;

	@Override
	public Mono<Booking> createBooking(Booking booking) {
		// TODO Auto-generated method stub
		return bookingRepository.save(booking);
	}

	@Override
	public Mono<Booking> getBookingStatus(Long id) {
		// TODO Auto-generated method stub
		return bookingRepository.findById(id);
	}
	
	
	

}
