package com._p.Bawarchie_reactive.service;

import com._p.Bawarchie_reactive.entity.Booking;

import reactor.core.publisher.Mono;

public interface BookingService {
	
	Mono<Booking> createBooking(Booking booking);
	
	Mono<Booking> getBookingStatus(Long id);

}
