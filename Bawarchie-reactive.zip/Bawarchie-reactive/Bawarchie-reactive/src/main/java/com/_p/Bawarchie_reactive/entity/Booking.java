package com._p.Bawarchie_reactive.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name="bookings")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Booking {

	@Id
	private Long id;
	private String username;
	private String datestring;
	private String timestring;
	private Integer guests;
	private String bookingstatus;




}
