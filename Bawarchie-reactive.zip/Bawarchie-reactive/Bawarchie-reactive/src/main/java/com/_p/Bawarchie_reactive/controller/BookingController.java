package com._p.Bawarchie_reactive.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com._p.Bawarchie_reactive.entity.Booking;
import com._p.Bawarchie_reactive.service.BookingService;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("api/bookings")
public class BookingController {
	
	@Autowired
	private BookingService bookingService;
	
	
	
	private static final String BOOKING_ID = "bookingId";
	private static final String BOOKING_STATUS = "booking Status";

	
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Mono<Booking> createBooking(@RequestBody Booking booking) {
		return bookingService.createBooking(booking);
	}
	
	public Mono<ResponseEntity<Booking>> getBookingStatus(@PathVariable Long id) {
		return bookingService.getBookingStatus(id)
				.map(booking -> ResponseEntity.ok(booking))
				.defaultIfEmpty(ResponseEntity.notFound().build());
	}

}
