/*
 * package com._p.Bawarchie_reactive.configuration;
 * 
 * import java.sql.Connection; import java.sql.ResultSet; import
 * java.sql.SQLException; import java.sql.Statement;
 * 
 * import javax.sql.DataSource;
 * 
 * import org.springframework.stereotype.Component;
 * 
 * @Component public class DatabaseComponent {
 * 
 * private final DataSource dataSource;
 * 
 * public DatabaseComponent(DataSource dataSource) { this.dataSource =
 * dataSource; }
 * 
 * public void executeQuery() throws SQLException { String query =
 * "SELECT * FROM order"; try (Connection connection =
 * dataSource.getConnection(); Statement statement =
 * connection.createStatement(); ResultSet resultSet =
 * statement.executeQuery(query)) { } catch (SQLException e) {
 * e.printStackTrace(); } }
 * 
 * 
 * 
 * }
 */