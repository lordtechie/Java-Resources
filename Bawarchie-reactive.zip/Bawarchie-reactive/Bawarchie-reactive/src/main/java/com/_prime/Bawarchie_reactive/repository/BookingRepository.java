package com._prime.Bawarchie_reactive.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;

import com._p.Bawarchie_reactive.entity.Booking;

public interface BookingRepository extends R2dbcRepository<Booking , Long>{

}
