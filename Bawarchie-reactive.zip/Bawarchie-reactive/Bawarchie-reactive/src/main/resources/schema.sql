Create TABLE "bookings"(
    id INT NOT NULL ,
    username VARCHAR(255),
    datestring VARCHAR(255),
    timestring VARCHAR(255),
    guests INT,
    bookingstatus VARCHAR(255),
    PRIMARY KEY(id)
);