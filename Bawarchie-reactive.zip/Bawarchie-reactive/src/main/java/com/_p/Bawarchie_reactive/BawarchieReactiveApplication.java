package com._p.Bawarchie_reactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BawarchieReactiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(BawarchieReactiveApplication.class, args);
	}

}
