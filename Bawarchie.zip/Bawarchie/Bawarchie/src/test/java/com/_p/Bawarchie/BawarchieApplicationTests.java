package com._p.Bawarchie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BawarchieApplicationTests {

	@Test
	void contextLoads() {
	}

}
