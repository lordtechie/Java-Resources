
Create TABLE "menu_item" (
    id BIGINT GENRATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL
);

INSERT INTO "menu_item" (name, price) VALUES ('ShevBhaji', 70.50);
INSERT INTO "menu_item" (name, price) VALUES ('Pizza', 20.30);


UPDATE "menu_item" SET name = 'Vegeterian Pizza', price =  19.33 WHERE id = 2;

DELETE  FROM "menu_item" WHERE id = 1;

SELECT * FROM "menu_item";

SELECT * FROM "menu_item" WHERE id = 2;

SELECT * FROM "menu_item" WHERE name = 'Vegeterian Pizza';

