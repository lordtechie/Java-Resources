Create TABLE "bawarchie_table" (
    id BIGINT GENRATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    number INT NOT NULL UNIQUE,
    is_available BOOLEAN DEFAULT TRUE
);

INSERT INTO "bawarchie_table" (number, is_available) VALUES (1, TRUE);
INSERT INTO "bawarchie_table" (number, is_available) VALUES (1, FALSE);

UPDATE "bawarchie_table" SET is_available = TRUE WHERE number = 2;

DELETE  FROM "bawarchie_table" WHERE number = 1;

SELECT *  FROM "bawarchie_table";

SELECT * FROM "bawarchie_table" WHERE number = 2;