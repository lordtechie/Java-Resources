ALTER TABLE "order_details"
ADD CONSTRAINTS  FK12atu0rk50jrsa41i1gkekfkw FOREIGN KEY ("menu_id") REFERENCES "menu_item";

ALTER TABLE "order_details"
ADD CONSTRAINTS  FK1kv7o7rgyuc66y9hqyuyvdp5p FOREIGN KEY ("table_id") REFERENCES "bawarchie_table";


Create TABLE "order_details" (
    id BIGINT GENRATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    table_id BIGINT NOT NULL,
    menu_id BIGINT NOT NULL,
    description VARCHAR(255),
    is_completed BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (table_id) REFERENCES "bawarchie_table"(id),
    FOREIGN KEY (menu_id) REFERENCES "menu_item"(id),
);


INSERT INTO "order_details" (table_id, menu_id, description, is_completed) VALUES (1, 1, "Extra cheese", FALSE);
INSERT INTO "order_details" (table_id, menu_id, description, is_completed) VALUES (1, 2, "Extra spicy", FALSE);

UPDATE "order_details" SET description = "medium", is_completed = TRUE WHERE id = 1;

DELETE * FROM "order_details" WHERE id =1;

SELECT * FROM "order_details";

SELECT * FROM "order_details" WHERE id =1;

SELECT * FROM "order_details" WHERE table_id = 1;

SELECT * FROM "order_details" WHERE menu_id = 1;





