package com._p.Bawarchie.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com._p.Bawarchie.entity.Table;
import com._p.Bawarchie.service.TableService;

@RestController
@RequestMapping("/tables")
public class TableController {
	
	@Autowired
	private TableService tableService;
	
	@GetMapping("status")
	public Table checkTableStatus(@RequestParam int number) {
		return tableService.checkTableStatus(number);
	}
	
	@GetMapping("all")
	public List<Table> getAllTables() {
		return tableService.getAllTables();
	}
	
	@GetMapping("{number}")
	public Table  getTable(@PathVariable int number) {
		return tableService.getTable(number);
	}
	
	
	@PostMapping("book")
	public Table bookTable(@RequestBody HashMap<String,Integer> tableInfo) {
		if(tableInfo.get("number") != null) {
			
			return tableService.bookTable(tableInfo.get("number"));
		}else {
			return null;
		}
	}
	
	@PostMapping("add")
	public Table addTable(@RequestBody Table table) {
		return tableService.addTable(table.getNumber(),table.isAvailable());
	}
	
	@PutMapping("update/{number}")
	public Table  updateTable(@PathVariable int number, @RequestParam boolean isAvailable) {
		return tableService.updateTable(number, isAvailable);
	}
	
	@DeleteMapping("delete/{number}")
	public void deleteTable(@PathVariable int number) {
		 tableService.deleteTable(number);
	}
	
	
	
	

}
