package com._p.Bawarchie.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com._p.Bawarchie.entity.Table;

public interface TableRepository extends ReactiveCrudRepository<Table, Long>{
	Table findByNumber(int number);
	

}
