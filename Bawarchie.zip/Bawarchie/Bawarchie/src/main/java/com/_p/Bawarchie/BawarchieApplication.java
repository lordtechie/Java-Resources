package com._p.Bawarchie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BawarchieApplication {

	public static void main(String[] args) {
		SpringApplication.run(BawarchieApplication.class, args);
	}

}
