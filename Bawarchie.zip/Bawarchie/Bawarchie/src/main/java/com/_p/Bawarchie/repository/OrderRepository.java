package com._p.Bawarchie.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com._p.Bawarchie.entity.Menu;
import com._p.Bawarchie.entity.Order;
import com._p.Bawarchie.entity.Table;

import reactor.core.publisher.Flux;

public interface OrderRepository extends ReactiveCrudRepository<Order, Long> {

	Flux <Order> findByTable(Table table);
	Flux <Order> findByMenu(Menu menu);

}
