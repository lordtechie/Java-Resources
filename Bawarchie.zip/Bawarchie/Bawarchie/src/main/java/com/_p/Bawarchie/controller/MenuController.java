package com._p.Bawarchie.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com._p.Bawarchie.entity.Menu;
import com._p.Bawarchie.service.MenuService;

@RestController
@RequestMapping("menu")
public class MenuController {

	@Autowired
	private MenuService menuService;
	
	@GetMapping("all")
	public List<Menu> getMenuItems() {
		return menuService.getAllMenuItem();
	}
	
	@GetMapping("{id}")
	public Menu getMenuItem(@PathVariable Long id) {
		return menuService.getMenuItem(id);
	}
	
	@GetMapping("name/{name}")
	public Menu getMenuItemByName(@PathVariable String name) {
		return menuService.getMenuItemByName(name);
	}
	
	@PostMapping("add")
	public Menu addMenuItem(@RequestBody Menu menu) {
		return menuService.addMenuItem(menu.getName(), menu.getPrice());
	}
	
	@PutMapping("update/{id}")
	public Menu updateMenuItem(@PathVariable Long id, @RequestParam String name, @RequestParam double price) {
		return menuService.updateMenuItem(id, name, price);
	}
	

	@DeleteMapping("delete/{id}")
	public void deleteMenuItem(@PathVariable Long id) {
		 menuService.deleteMenuItem(id);
	}
}
