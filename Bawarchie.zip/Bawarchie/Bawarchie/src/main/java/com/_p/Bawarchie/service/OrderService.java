package com._p.Bawarchie.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com._p.Bawarchie.entity.Menu;
import com._p.Bawarchie.entity.Order;
import com._p.Bawarchie.entity.Table;
import com._p.Bawarchie.repository.MenuRepository;
import com._p.Bawarchie.repository.OrderRepository;
import com._p.Bawarchie.repository.TableRepository;

import reactor.core.publisher.Mono;

@Service
public class OrderService {

	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private TableRepository tableRepository;

	
	@Autowired
	private MenuRepository menuRepository;
	
	
	
	public Mono<Order> placeOrder(Long tableId, Long menuId, String description) {
		
		Table table = new Table();
		table.setId(1L);
		table.setAvailable(false);
		table.setNumber(1);
		
		
		Menu menu = new Menu();
		menu.setId(1L);
		menu.setName("pizza");
		menu.setPrice(19.99);

		if (table != null && !table.isAvailable() && menu != null) {
			Order order = new Order();
			order.setDescription(description);
			order.setTable(table);
			order.setMenu(menu);
			Mono.just(order);
			orderRepository.save(order);
		}
		return null;
	}
	
//	public Mono<Order> checkOrderStatus(Long orderId) {
//		return orderRepository.findById(orderId).orElse(null);
//	}
//	
//	public Flux<Order> getOrdersForTable(int tableNumber) {
//		Table table = tableRepository.findByNumber(tableNumber);
//		return orderRepository.findByTable(table);
//	}
//	
//	public List<Order> getOrdersForMenu(Long menuId) {
//		Menu menu = menuRepository.findById(menuId).orElse(null);
//		return orderRepository.findByMenu(menu);
//	}
//	
//	public Order updateOrder(Long orderId, String description, boolean isCompleted) {
//		Order order = orderRepository.findById(orderId).orElse(null);
//
//		if (order != null) {
//			order.setDescription(description);
//			order.setCompleted(isCompleted);
//			return orderRepository.save(order);
//		}
//		return null;
//	}
	
	public void deleteOrder(Long orderId) {
		 orderRepository.deleteById(orderId);
	}
	
}
