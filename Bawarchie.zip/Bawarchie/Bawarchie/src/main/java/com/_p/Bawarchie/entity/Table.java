package com._p.Bawarchie.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "bawarchie_table")
public class Table {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private int number;
	
	@Column(name = "is_available")
	private boolean isAvailable=true;
	
	
	
	public Table(Long id, int number, boolean isAvailable) {
		super();
		this.id = id;
		this.number = number;
		this.isAvailable = isAvailable;
	}
	
	
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public boolean isAvailable() {
		return isAvailable;
	}
	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	@Override
	public String toString() {
		return "Table [id=" + id + ", number=" + number + ", isAvailable=" + isAvailable + "]";
	}




	public Table() {
		super();
	}
	
	
	
	
}
