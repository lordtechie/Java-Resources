package com._p.Bawarchie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com._p.Bawarchie.entity.Table;
import com._p.Bawarchie.repository.TableRepository;

@Service
public class TableService {
	
	@Autowired
	private TableRepository tableRepository;
	
	
	
	public Table addTable(int tableNumber, boolean isAvailable) {
		Table table = new Table(); 
			table.setAvailable(isAvailable);
			table.setNumber(tableNumber);
			return tableRepository.save(table);
		}
	
	public Table getTable(int number) {		
		return tableRepository.findByNumber(number);
	}
		
	public Table bookTable(int tableNumber) {
		Table table = tableRepository.findByNumber(tableNumber);
		if (table != null && table.isAvailable()) {
			table.setAvailable(false);
			return tableRepository.save(table);
		}
		return null;
	}
	
	public Table checkTableStatus(int tableNumber) {
		return tableRepository.findByNumber(tableNumber);
	}

	public List<Table> getAllTables() {
		return tableRepository.findAll();
	}
	
	public Table updateTable(int number, boolean isAvailable) {
		Table table = tableRepository.findByNumber(number);
		if (table != null) {
			table.setAvailable(isAvailable);
			return tableRepository.save(table);
		}
		return null;
	}
	
	public void deleteTable(int number) {
		Table table = tableRepository.findByNumber(number);
		if (table != null) {
			 tableRepository.delete(table);

		}
	}
	
}
