package com._p.Bawarchie.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com._p.Bawarchie.entity.Menu;

public interface MenuRepository extends ReactiveCrudRepository<Menu, Long>{
	Menu findByName(String name);

}
