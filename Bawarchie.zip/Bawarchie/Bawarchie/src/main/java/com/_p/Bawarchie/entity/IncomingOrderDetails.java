package com._p.Bawarchie.entity;

public class IncomingOrderDetails {

	
	private Long tableId;
	private Long menuId;
	private String description;
	
	
	
	public Long getTableNumber() {
		return tableId;
	}
	public void setTableNumber(Long tableId) {
		this.tableId = tableId;
	}
	public Long getMenuId() {
		return menuId;
	}
	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public IncomingOrderDetails(Long tableId, Long menuId, String description) {
		super();
		this.tableId = tableId;
		this.menuId = menuId;
		this.description = description;
	}
	
	
}
