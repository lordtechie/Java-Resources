package com._p.Bawarchie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com._p.Bawarchie.entity.Menu;
import com._p.Bawarchie.repository.MenuRepository;

@Service
public class MenuService {

	@Autowired
	private MenuRepository menuRepository;
	
	public Menu addMenuItem(String name, double price) {
		Menu menu = new Menu();
		menu.setName(name);
		menu.setPrice(price);
		return menuRepository.save(menu);
	}
	
	public Menu getMenuItem(Long id) {
		return menuRepository.findById(id).orElse(null);
	}
	
	public Menu getMenuItemByName(String name) {
		return menuRepository.findByName(name);
	}
	
	public List<Menu> getAllMenuItem() {
		return menuRepository.findAll();
	}
	
	public Menu updateMenuItem(Long id, String name, double price) {
		Menu menu = menuRepository.findById(id).orElse(null);
		if (menu != null) {
			menu.setName(name);
			menu.setPrice(price);
			return menuRepository.save(menu);
		}
		return null;
	}
	

}
