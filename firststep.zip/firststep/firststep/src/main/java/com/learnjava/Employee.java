package com.learnjava;

public interface Employee {
    default String getSalary() {
        return "100";
    }

    default String getDesignation() {
        return "Software Engineer";
    }
}
