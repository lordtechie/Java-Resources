package com.learnjava.collection;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class collection {
    public static void main(String[] args) throws Exception {

        ArrayList<Integer> arr = new ArrayList<>();
        arr.add(10);
        arr.add(20);
        arr.add(30);
        arr.add(40);

        System.out.println("List: " + arr);

        int element = arr.get(2);

        System.out.println("the element at index 2 is " + element) ;


        ArrayList<String> list = new ArrayList<>();
        list.add("Tejas");
        list.add("Digu");
        list.add("Abhay");
        list.add("Aja");
        list.add("Tailor");

        System.out.println("The list is: " + list);
        Iterator<String> iter = list.iterator();

        System.out.println("/n The iterator values" + " of list are: " );
        while (iter.hasNext()) {
            System.out.println(iter.next());
        }

        try {
            AbstractList<Integer> arrlist1 =
                    new ArrayList<Integer>();

            arrlist1.add(10);
            arrlist1.add(20);
            arrlist1.add(30);
            arrlist1.add(40);
            arrlist1.add(50);
            System.out.println("Arraylist : " + arrlist1);

            Iterator it = arrlist1.iterator();

            while (it.hasNext()) {
                System.out.println("value is : " + it.next());
            }
        }

        catch (NullPointerException e) {
            System.out.println("Exception thrown : " + e);
        }

        ArrayList<Integer> Arrlis
                = new ArrayList<Integer>();
        Arrlis.add(32);
        Arrlis.add(64);
        Arrlis.add(97);
        Arrlis.add(78);

        System.out.println(" ArrayList: " + Arrlis);

        Integer att[] = new Integer[Arrlis.size()];
        att = Arrlis.toArray(att);

        System.out.println("Elements of ArrayList " +
                "as Array: "
                + Arrays.toString(att));

    }
}
