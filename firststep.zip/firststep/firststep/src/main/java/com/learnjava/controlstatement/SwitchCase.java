package com.learnjava.controlstatement;

import java.util.Scanner;

public class SwitchCase {
    public static void main(String[] args) {
        int a =20,b =40,ch;
        System.out.print("Enter user choice...!/n");
        Scanner r = new Scanner(System.in);
        ch = r.nextInt();
        switch (ch)
        {
            case 1:System.out.print("Sum " + (a+b));
            break;
            case 2:System.out.print("Sub " + (a-b));
            break;
            case 3:System.out.print("Multi " + (a*b));
            break;
            case 4:System.out.print("Div " + (b/a));
            break;
            default:System.out.print("Invalid choice....!");
        }

    }
}
