package com.learnjava.controlstatement;

public class ControlStatement {
    public static void main(String[] args) {
        //if-else-if ladder
        int X;

        for (X = 0; X < 5; X++) {
            if (X == 1)
                System.out.println("X is 1");
            else if (X == 2)
            System.out.println("X is 2");
            else if (X == 3)
            System.out.println("X is 3");
            else if (X == 4)
            System.out.println("X is 4");
            else
                System.out.println("X is not bt");
        }
    }
}
