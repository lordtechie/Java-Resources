package com.p.learn_jpa_and_hibernate.course.jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.p.learn_jpa_and_hibernate.course.Course;
import com.p.learn_jpa_and_hibernate.course.springdatajpa.CourseSpringDataJpaRepository;

@Component
public class CourseCommandLineRunner implements CommandLineRunner {

	/*
	 * @Autowired private CourseJdbcRepository repository;
	 * 
	 * 
	 * @Autowired private CourseJpaReporsitory repository;
	 * 
	 */
	
	@Autowired
	private CourseSpringDataJpaRepository repository;
	
	
	@Override
	public void run(String... args) throws Exception {
		repository.save(new Course(1, "Learn-AWS Jpa!", "10P"));
		repository.save(new Course(2, "Learn-Java Jpa!", "10P"));
		repository.save(new Course(3, "Learn-Azure Jpa!", "10P"));

		repository.deleteById(1l);

		System.out.println(repository.findById(2l));
		System.out.println(repository.findById(3l));
		
		System.out.println(repository.findAll());
		System.out.println(repository.count());
		
		//custom methods in interface
		System.out.println(repository.findByAuthor("10P"));
		System.out.println(repository.findByAuthor(""));

		System.out.println(repository.findByName("Learn-AWS Jpa!"));
		System.out.println(repository.findByName("Learn-Azure Jpa!"));




	}

}
