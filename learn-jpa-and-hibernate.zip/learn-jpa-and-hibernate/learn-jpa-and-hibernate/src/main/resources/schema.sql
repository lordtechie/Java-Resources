create table course 
(
       id BIGINT NOT NULL,
       name VARCHAR(255) NOT NULL,
       author VARCHAR(255) NOT NULL,
       PRIMARY KEY (id)
);
 

