package com.prime.taj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TajApplication {

	public static void main(String[] args) {
		SpringApplication.run(TajApplication.class, args);
	}

}
