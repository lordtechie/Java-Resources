package com.prime.taj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TajApplicationTests {

	@Test
	void contextLoads() {
	}

}
